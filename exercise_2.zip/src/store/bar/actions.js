export function addDrink(drink) {
	return {
		type: 'ADD_DRINK',
		payload: drink,
	};
}
