const reducers = {
	bar: require('./bar/reducer').default,
};

export default reducers;
